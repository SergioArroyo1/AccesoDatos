import java.io.Serializable;
import java.time.LocalDate;

public class Venta implements Serializable {
    private String dniCliente;
    private String isbnLibro;
    private LocalDate fecha;
    private int unidades;
    private double total;

    public Venta(String dniCliente, String isbnLibro, LocalDate fecha, int unidades, double total) {
        this.dniCliente = dniCliente;
        this.isbnLibro = isbnLibro;
        this.fecha = fecha;
        this.unidades = unidades;
        this.total = total;
    }

    public String getDniCliente() { return dniCliente; }
    public String getIsbnLibro() { return isbnLibro; }
    public LocalDate getFecha() { return fecha; }
    public int getUnidades() { return unidades; }
    public double getTotal() { return total; }

    @Override
    public String toString() {
        return "Cliente: " + dniCliente + " | Libro: " + isbnLibro + " | Fecha: " + fecha +
                " | Unidades: " + unidades + " | Total: " + total + "€";
    }
}


