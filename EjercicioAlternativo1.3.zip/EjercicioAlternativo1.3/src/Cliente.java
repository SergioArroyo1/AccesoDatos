
import java.io.Serializable;

public class Cliente implements Serializable {
    private String dni;
    private String nombre;
    private String email;
    private String telefono;
    private int totalCompras;

    public Cliente(String dni, String nombre, String email, String telefono) {
        this.dni = dni;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.totalCompras = 0;
    }

    public String getDni() { return dni; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getTelefono() { return telefono; }
    public int getTotalCompras() { return totalCompras; }

    public void setEmail(String email) { this.email = email; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void sumarCompras(int cantidad) { this.totalCompras += cantidad; }

    @Override
    public String toString() {
        return dni + " | " + nombre + " | " + email + " | " + telefono + " | Libros comprados: " + totalCompras;
    }
}

