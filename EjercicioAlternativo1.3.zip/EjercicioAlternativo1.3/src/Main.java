import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Libreria libreria = new Libreria();
        libreria.cargarDatos(); // carga los .dat al iniciar

        int opcion;

        do {
            System.out.println("\n===== LIBRERÍA 'EL RINCÓN DEL LIBRO' =====");
            System.out.println("1. Gestión de Libros");
            System.out.println("2. Gestión de Clientes");
            System.out.println("3. Registro de Ventas");
            System.out.println("4. Guardar y Salir");
            System.out.print("Seleccione una opción: ");

            opcion = leerEntero(sc);

            switch (opcion) {
                case 1 -> menuLibros(sc, libreria);
                case 2 -> menuClientes(sc, libreria);
                case 3 -> menuVentas(sc, libreria);
                case 4 -> {
                    libreria.guardarDatos();
                    System.out.println("Datos guardados. ¡Hasta pronto, Carmen!");
                }
                default -> System.out.println("Opción no válida. Intente de nuevo.");
            }

        } while (opcion != 4);
    }

    //  MENÚ LIBROS
    private static void menuLibros(Scanner sc, Libreria libreria) {
        int opcion;
        do {
            System.out.println("\n--- GESTIÓN DE LIBROS ---");
            System.out.println("1. Añadir nuevo libro");
            System.out.println("2. Ver listado completo");
            System.out.println("3. Buscar libro por ISBN");
            System.out.println("4. Buscar por categoría");
            System.out.println("5. Actualizar stock");
            System.out.println("6. Ver libros con menos de 5 unidades");
            System.out.println("7. Volver al menú principal");
            System.out.print("Elija una opción: ");
            opcion = leerEntero(sc);

            switch (opcion) {
                case 1 -> libreria.anadirLibro(sc);
                case 2 -> libreria.listarLibros();
                case 3 -> libreria.buscarLibroPorISBN(sc);
                case 4 -> libreria.buscarPorCategoria(sc);
                case 5 -> libreria.actualizarStock(sc);
                case 6 -> libreria.listarLibrosBajoStock();
                case 7 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 7);
    }

    // MENÚ CLIENTES
    private static void menuClientes(Scanner sc, Libreria libreria) {
        int opcion;
        do {
            System.out.println("\n--- GESTIÓN DE CLIENTES ---");
            System.out.println("1. Alta de nuevo cliente");
            System.out.println("2. Ver listado completo");
            System.out.println("3. Buscar cliente por DNI");
            System.out.println("4. Ver 5 mejores clientes");
            System.out.println("5. Actualizar datos de contacto");
            System.out.println("6. Volver al menú principal");
            System.out.print("Elija una opción: ");
            opcion = leerEntero(sc);

            switch (opcion) {
                case 1 -> libreria.anadirCliente(sc);
                case 2 -> libreria.listarClientes();
                case 3 -> libreria.buscarClientePorDNI(sc);
                case 4 -> libreria.verMejoresClientes();
                case 5 -> libreria.actualizarCliente(sc);
                case 6 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 6);
    }

    //  MENÚ VENTAS
    private static void menuVentas(Scanner sc, Libreria libreria) {
        int opcion;
        do {
            System.out.println("\n--- REGISTRO DE VENTAS ---");
            System.out.println("1. Registrar nueva venta");
            System.out.println("2. Ver ventas por fecha");
            System.out.println("3. Ver ventas por cliente");
            System.out.println("4. Ver ventas por libro");
            System.out.println("5. Ver total ganado");
            System.out.println("6. Volver al menú principal");
            System.out.print("Elija una opción: ");
            opcion = leerEntero(sc);

            switch (opcion) {
                case 1 -> libreria.registrarVenta(sc);
                case 2 -> libreria.verVentasPorFecha(sc);
                case 3 -> libreria.verVentasPorCliente(sc);
                case 4 -> libreria.verVentasPorLibro(sc);
                case 5 -> libreria.verTotalGanado();
                case 6 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 6);
    }

    // VALIDACIÓN DE ENTRADAS
    private static int leerEntero(Scanner sc) {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida. Introduzca un número: ");
            }
        }
    }
}
