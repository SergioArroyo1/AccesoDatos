import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;

public class Libreria {
    private Libro[] libros = new Libro[500];
    private Cliente[] clientes = new Cliente[200];
    private Venta[] ventas = new Venta[1000];

    private int numLibros = 0;
    private int numClientes = 0;
    private int numVentas = 0;

    private final String CARPETA = "datos_libreria";
    private final String ARCH_LIBROS = CARPETA + "/libros.dat";
    private final String ARCH_CLIENTES = CARPETA + "/clientes.dat";
    private final String ARCH_VENTAS = CARPETA + "/ventas.dat";

    public Libreria() {
        File dir = new File(CARPETA);
        if (!dir.exists()) dir.mkdir();
    }

    // GESTIÓN DE LIBROS
    public void anadirLibro(Scanner sc) {
        if (numLibros >= libros.length) {
            System.out.println("No caben más libros.");
            return;
        }

        System.out.print("ISBN: ");
        String isbn = sc.nextLine();
        if (buscarLibro(isbn) != -1) {
            System.out.println("Ya existe un libro con ese ISBN.");
            return;
        }

        System.out.print("Título: ");
        String titulo = sc.nextLine();
        System.out.print("Autor: ");
        String autor = sc.nextLine();
        System.out.print("Categoría: ");
        String categoria = sc.nextLine();
        System.out.print("Precio: ");
        double precio = leerDouble(sc);
        System.out.print("Stock inicial: ");
        int stock = leerEntero(sc);

        libros[numLibros++] = new Libro(isbn, titulo, autor, categoria, precio, stock);
        System.out.println("Libro añadido correctamente.");
    }

    public void listarLibros() {
        if (numLibros == 0) {
            System.out.println("No hay libros registrados.");
            return;
        }
        for (int i = 0; i < numLibros; i++) {
            System.out.println(libros[i]);
        }
    }

    public void buscarLibroPorISBN(Scanner sc) {
        System.out.print("Ingrese ISBN: ");
        String isbn = sc.nextLine();
        int pos = buscarLibro(isbn);
        if (pos == -1) System.out.println("No se encontró el libro.");
        else System.out.println(libros[pos]);
    }

    public void buscarPorCategoria(Scanner sc) {
        System.out.print("Categoría: ");
        String cat = sc.nextLine();
        boolean encontrado = false;
        for (int i = 0; i < numLibros; i++) {
            if (libros[i].getCategoria().equalsIgnoreCase(cat)) {
                System.out.println(libros[i]);
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("No hay libros de esa categoría.");
    }

    public void actualizarStock(Scanner sc) {
        System.out.print("ISBN: ");
        String isbn = sc.nextLine();
        int pos = buscarLibro(isbn);
        if (pos == -1) {
            System.out.println("Libro no encontrado.");
            return;
        }
        System.out.print("Unidades a sumar: ");
        int unidades = leerEntero(sc);
        libros[pos].setStock(libros[pos].getStock() + unidades);
        System.out.println("Stock actualizado.");
    }

    public void listarLibrosBajoStock() {
        boolean encontrado = false;
        for (int i = 0; i < numLibros; i++) {
            if (libros[i].getStock() < 5) {
                System.out.println(libros[i]);
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("Todos los libros tienen suficiente stock.");
    }

    // GESTIÓN DE CLIENTES
    public void anadirCliente(Scanner sc) {
        if (numClientes >= clientes.length) {
            System.out.println("No caben más clientes.");
            return;
        }

        System.out.print("DNI: ");
        String dni = sc.nextLine();
        if (buscarCliente(dni) != -1) {
            System.out.println("Ya existe un cliente con ese DNI.");
            return;
        }

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Teléfono: ");
        String telefono = sc.nextLine();

        clientes[numClientes++] = new Cliente(dni, nombre, email, telefono);
        System.out.println("Cliente añadido correctamente.");
    }

    public void listarClientes() {
        if (numClientes == 0) {
            System.out.println("No hay clientes registrados.");
            return;
        }
        for (int i = 0; i < numClientes; i++) {
            System.out.println(clientes[i]);
        }
    }

    public void buscarClientePorDNI(Scanner sc) {
        System.out.print("DNI: ");
        String dni = sc.nextLine();
        int pos = buscarCliente(dni);
        if (pos == -1) System.out.println("No se encontró el cliente.");
        else System.out.println(clientes[pos]);
    }

    public void verMejoresClientes() {
        if (numClientes == 0) {
            System.out.println("No hay clientes.");
            return;
        }

        // Orden simple (burbuja)
        for (int i = 0; i < numClientes - 1; i++) {
            for (int j = 0; j < numClientes - i - 1; j++) {
                if (clientes[j].getTotalCompras() < clientes[j + 1].getTotalCompras()) {
                    Cliente tmp = clientes[j];
                    clientes[j] = clientes[j + 1];
                    clientes[j + 1] = tmp;
                }
            }
        }

        System.out.println("--- TOP 5 CLIENTES ---");
        for (int i = 0; i < numClientes && i < 5; i++) {
            System.out.println(clientes[i]);
        }
    }

    public void actualizarCliente(Scanner sc) {
        System.out.print("DNI del cliente: ");
        String dni = sc.nextLine();
        int pos = buscarCliente(dni);
        if (pos == -1) {
            System.out.println("No existe el cliente.");
            return;
        }
        System.out.print("Nuevo email: ");
        String email = sc.nextLine();
        System.out.print("Nuevo teléfono: ");
        String tel = sc.nextLine();

        clientes[pos].setEmail(email);
        clientes[pos].setTelefono(tel);
        System.out.println("Datos actualizados.");
    }

    // GESTIÓN DE VENTAS
    public void registrarVenta(Scanner sc) {
        if (numVentas >= ventas.length) {
            System.out.println("No caben más ventas.");
            return;
        }

        System.out.print("DNI del cliente: ");
        String dni = sc.nextLine();
        int posCliente = buscarCliente(dni);
        if (posCliente == -1) {
            System.out.println("Cliente no encontrado.");
            return;
        }

        System.out.print("ISBN del libro: ");
        String isbn = sc.nextLine();
        int posLibro = buscarLibro(isbn);
        if (posLibro == -1) {
            System.out.println("Libro no encontrado.");
            return;
        }

        System.out.print("Unidades vendidas: ");
        int unidades = leerEntero(sc);
        if (libros[posLibro].getStock() < unidades) {
            System.out.println("No hay suficiente stock.");
            return;
        }

        double total = libros[posLibro].getPrecio() * unidades;
        libros[posLibro].setStock(libros[posLibro].getStock() - unidades);
        clientes[posCliente].sumarCompras(unidades);
        ventas[numVentas++] = new Venta(dni, isbn, LocalDate.now(), unidades, total);
        System.out.println("Venta registrada. Total: " + total + "€");
    }

    public void verVentasPorFecha(Scanner sc) {
        System.out.print("Ingrese fecha (AAAA-MM-DD): ");
        String fecha = sc.nextLine();
        boolean encontrado = false;
        for (int i = 0; i < numVentas; i++) {
            if (ventas[i].getFecha().toString().equals(fecha)) {
                System.out.println(ventas[i]);
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("No hay ventas en esa fecha.");
    }

    public void verVentasPorCliente(Scanner sc) {
        System.out.print("DNI cliente: ");
        String dni = sc.nextLine();
        boolean encontrado = false;
        for (int i = 0; i < numVentas; i++) {
            if (ventas[i].getDniCliente().equals(dni)) {
                System.out.println(ventas[i]);
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("No hay ventas de ese cliente.");
    }

    public void verVentasPorLibro(Scanner sc) {
        System.out.print("ISBN libro: ");
        String isbn = sc.nextLine();
        boolean encontrado = false;
        for (int i = 0; i < numVentas; i++) {
            if (ventas[i].getIsbnLibro().equals(isbn)) {
                System.out.println(ventas[i]);
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("No hay ventas de ese libro.");
    }

    public void verTotalGanado() {
        double total = 0;
        for (int i = 0; i < numVentas; i++) {
            total += ventas[i].getTotal();
        }
        System.out.println("Total ganado: " + total + "€");
    }

    //  GUARDAR Y CARGAR DATOS
    public void guardarDatos() {
        guardarArray(libros, numLibros, ARCH_LIBROS);
        guardarArray(clientes, numClientes, ARCH_CLIENTES);
        guardarArray(ventas, numVentas, ARCH_VENTAS);
    }

    public void cargarDatos() {
        numLibros = cargarArray(libros, ARCH_LIBROS);
        numClientes = cargarArray(clientes, ARCH_CLIENTES);
        numVentas = cargarArray(ventas, ARCH_VENTAS);
    }

    private void guardarArray(Object[] array, int cantidad, String archivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            for (int i = 0; i < cantidad; i++) {
                oos.writeObject(array[i]);
            }
        } catch (IOException e) {
            System.out.println("Error guardando datos: " + e.getMessage());
        }
    }

    private int cargarArray(Object[] array, String archivo) {
        int cont = 0;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            while (true) {
                array[cont++] = ois.readObject();
            }
        } catch (EOFException e) {
            // fin del archivo
        } catch (Exception e) {
            // archivo vacío o inexistente
        }
        return cont;
    }

    //  MÉTODOS AUXILIARES
    private int buscarLibro(String isbn) {
        for (int i = 0; i < numLibros; i++) {
            if (libros[i].getIsbn().equals(isbn)) return i;
        }
        return -1;
    }

    private int buscarCliente(String dni) {
        for (int i = 0; i < numClientes; i++) {
            if (clientes[i].getDni().equals(dni)) return i;
        }
        return -1;
    }

    private static int leerEntero(Scanner sc) {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Introduzca un número válido: ");
            }
        }
    }

    private static double leerDouble(Scanner sc) {
        while (true) {
            try {
                return Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Introduzca un número válido: ");
            }
        }
    }
}



